using Loader;
using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace KeyAuth
{
    public partial class Main : Form
    {
        string chatchannel = "";
        public Main()
        {
            InitializeComponent();
            Drag.MakeDraggable(this);
        }
        public static bool SubExist(string name, int len)
        {
            for (var i = 0; i < len; i++)
            {
                if (Login.KeyAuthApp.user_data.subscriptions[i].subscription == name)
                {
                    return true;
                }
            }
            return false;
        }
        private async void closeBtn_Click(object sender, EventArgs e)
        {
            await Login.KeyAuthApp.logout();
            Environment.Exit(0);
        }
        private void minBtn_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }
        private async void banBtn_Click(object sender, EventArgs e)
        {
            await Login.KeyAuthApp.ban("Testing ban function");
            MessageBox.Show(Login.KeyAuthApp.response.message);
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string downloadUrl = "https://github.com/iiDk-the-actual/iis.Stupid.Menu/releases/latest/download/iis_Stupid_Menu.dll"; // link for your menu so discord link or any other link
            try
            {
                string targetFolder = null;
                string steamPath = @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag\BepInEx\plugins";
                if (Directory.Exists(steamPath))
                {
                    targetFolder = steamPath;
                }
                else
                {
                    string oculusPath = @"C:\Program Files\Oculus\Software\Software\another-axiom-gorilla-tag";
                    if (Directory.Exists(oculusPath))
                    {
                        targetFolder = oculusPath;
                    }
                }
                if (targetFolder == null)
                {
                    FolderBrowserDialog folderDialog = new FolderBrowserDialog();
                    folderDialog.Description = "Select the plugins folder where the DLL should be installed";
                    if (folderDialog.ShowDialog() == DialogResult.OK)
                    {
                        targetFolder = folderDialog.SelectedPath;
                    }
                    else
                    {
                        MessageBox.Show("Installation canceled - no target folder selected", "Canceled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
                string tempFile = Path.Combine(Path.GetTempPath(), "Hostility.dll");
                using (WebClient client = new WebClient())
                {
                    client.DownloadFile(downloadUrl, tempFile);
                }
                string fileName = "Hostility.dll"; 
                string destinationPath = Path.Combine(targetFolder, fileName);
                if (File.Exists(destinationPath))
                {
                    File.Delete(destinationPath);
                }
                File.Move(tempFile, destinationPath);
                MessageBox.Show($"DLL successfully installed!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Failed to install DLL - please disable your antivirus/Windows Defender and try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (WebException webEx)
            {
                MessageBox.Show($"Failed to download the DLL: {webEx.Message}", "Download Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start("https://discord.gg/Xr2jwRa3qs");
        }
    }
}